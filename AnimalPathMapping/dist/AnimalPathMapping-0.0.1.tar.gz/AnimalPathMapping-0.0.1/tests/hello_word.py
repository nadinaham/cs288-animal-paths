"""
This file is temporary for testing that our Python package works.
"""

def hello_world():
    print("Hello world!  This package is running!")